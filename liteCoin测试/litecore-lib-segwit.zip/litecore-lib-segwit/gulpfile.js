

var litecoreTasks = require('litecore-build');

litecoreTasks('lib');
