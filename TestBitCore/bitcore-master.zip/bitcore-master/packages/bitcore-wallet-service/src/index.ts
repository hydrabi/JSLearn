import { ExpressApp } from './lib/expressapp';
import { Storage } from './lib/storage';

const BWS = {
  ExpressApp,
  Storage
};

module.exports = BWS;
