var Providers = {
  BitPay: require('./bitpay'),
//  Bitstamp: require('./bitstamp'), // no longer used
};

module.exports = Providers;
