var bitcore = require('bitcore-lib-cash');
bitcore.P2P = require('./lib');

module.exports = bitcore.P2P;
