# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [8.1.1](https://github.com/bitpay/bitcore-p2p/compare/v8.1.0...v8.1.1) (2019-03-21)

**Note:** Version bump only for package bitcore-p2p-cash

## [8.1.0](https://github.com/bitpay/bitcore-p2p/compare/v5.0.0-beta.44...v8.1.0) (2019-02-27)

**Note:** Version bump only for package bitcore-p2p-cash

## [8.0.0](https://github.com/bitpay/bitcore-p2p/compare/v5.0.0-beta.44...v8.0.0) (2019-02-27)
