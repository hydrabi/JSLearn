type Mapping<V> = { [key: string]: V };
