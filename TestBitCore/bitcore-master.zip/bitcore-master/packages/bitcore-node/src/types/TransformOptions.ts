export type TransformOptions = {object: boolean};
