type Class<T> = { new (...args: any[]): T };
