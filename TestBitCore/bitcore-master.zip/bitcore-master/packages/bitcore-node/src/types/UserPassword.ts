export type UserPassword = {
  username: string;
  password: string;
}
