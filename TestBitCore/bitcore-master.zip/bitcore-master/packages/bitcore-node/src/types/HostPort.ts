export type HostPort = {
  host: string;
  port: number;
}
