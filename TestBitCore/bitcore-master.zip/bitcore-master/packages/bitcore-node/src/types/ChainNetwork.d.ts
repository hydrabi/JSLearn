export type Chain = { chain: string };
export type Network = { network: string };
export type ChainNetwork = Chain & Network;
