import {expect} from 'chai';

describe('server', function(){
    it('should have a test which runs', function(){
        expect(true).to.equal(true);
    });
});