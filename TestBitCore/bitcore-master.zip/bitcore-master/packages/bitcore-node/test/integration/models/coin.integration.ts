import {expect} from 'chai';

describe('Coin Model', function(){
    it('should have a test which runs', function(){
        expect(true).to.equal(true);
    });
});