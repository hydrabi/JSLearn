
var startGulp = require('bitcore-build');
Object.assign(exports, startGulp('mnemonic'))

