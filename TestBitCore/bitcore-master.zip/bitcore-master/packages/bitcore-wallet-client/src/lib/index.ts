/**
 * The official client library for bitcore-wallet-service.
 * @module Client
 */

// /**
// * Client API.
// * @alias module:Client.API
// */
import { API } from './api';
export default API;
