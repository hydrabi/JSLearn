'use strict';

var startGulp = require('bitcore-build');
module.exports = startGulp('lib');
