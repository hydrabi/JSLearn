'use strict';

var startGulp = require('bitcore-build');
module.exports = startGulp('p2p', {skipBrowser: true})
