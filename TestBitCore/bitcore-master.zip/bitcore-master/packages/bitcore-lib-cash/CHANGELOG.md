# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [8.1.1](https://github.com/bitpay/bitcore-lib/tree/cash/compare/v8.1.0...v8.1.1) (2019-03-21)

**Note:** Version bump only for package bitcore-lib-cash

## [8.1.0](https://github.com/bitpay/bitcore-lib/tree/cash/compare/v5.0.0-beta.44...v8.1.0) (2019-02-27)

### Bug Fixes

* **lib-cash:** match bitcore-lib estimateFee fix ([8650345](https://github.com/bitpay/bitcore-lib/tree/cash/commit/8650345))

## [8.0.0](https://github.com/bitpay/bitcore-lib/tree/cash/compare/v5.0.0-beta.44...v8.0.0) (2019-02-27)

### Bug Fixes

* **lib-cash:** match bitcore-lib estimateFee fix ([8650345](https://github.com/bitpay/bitcore-lib/tree/cash/commit/8650345))
