import { Payment, PaymentOpts } from './index';
export declare function p2wpkh(a: Payment, opts?: PaymentOpts): Payment;
