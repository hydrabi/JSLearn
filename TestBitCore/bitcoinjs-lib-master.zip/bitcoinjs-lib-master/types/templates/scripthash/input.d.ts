export declare function check(script: Buffer | Array<number | Buffer>, allowIncomplete?: boolean): boolean;
export declare namespace check {
    var toJSON: () => string;
}
