'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
const output = require('./output');
exports.output = output;
