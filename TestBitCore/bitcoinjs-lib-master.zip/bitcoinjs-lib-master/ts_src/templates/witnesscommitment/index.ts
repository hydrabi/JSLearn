import * as output from './output';

export { output };
